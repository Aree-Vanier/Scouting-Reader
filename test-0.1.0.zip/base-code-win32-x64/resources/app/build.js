const packager = require("electron-packager")
const appPaths = await packager(options)
